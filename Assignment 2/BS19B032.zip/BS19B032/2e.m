%finding small worldness omega using given formula
omg = (Lr/L)-(C/CLatt);
disp('small worldness-omega is:');
disp(omg);